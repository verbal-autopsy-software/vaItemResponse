library(testthat)
library(vaItemResponse)

test_check("vaItemResponse")
